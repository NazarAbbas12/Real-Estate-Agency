document.getElementsByClassName('btn-primary')[0].addEventListener('click',function(){
    window.open('listing.html','_blank');
});


/*document.getElementsById("about").addEventListener('click',function()
{
    scrollBy;
})*/

document.getElementsByClassName('cta-button1')[0].addEventListener('click',function(){
    window.open('Contact.html','_blank')
});

document.getElementsByClassName('cta-button2')[0].addEventListener('click',function(){
    window.open('listing.html','_blank')
});
document.getElementsByClassName('cta-button3')[0].addEventListener('click',function(){
    window.open('listing.html','_blank')
});